<?php
	include "connect.php";
	$makhoa=$_POST['makhoa'];
	$str="delete from khoa where makhoa='$makhoa'";
	$str1="delete from bomon where makhoa='$makhoa'";
	if(mysql_query($str,$conn) && mysql_query($str1,$conn))
		echo "Xóa thành công";
	else
		echo "Xóa không được";
?>
