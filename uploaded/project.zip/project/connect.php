<?php
$SERVER = "localhost";
$USERNAME = "root";
$PASSWORD = "";
$DBNAME = "qlsv";
$conn = mysql_connect($SERVER, $USERNAME, $PASSWORD);
if (!$conn) {
    die("không nết nối được vào MySQL server") . error(conn);
}
//truy xuat du lieu tieng vien trong MySQL
mysql_query("SET NAMES 'utf8'");
mysql_select_db($DBNAME, $conn);
?>
