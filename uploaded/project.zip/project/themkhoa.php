<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
 <script src="jquery.js"></script>
<?php
include "connect.php";
        if(isset($_POST['them'])) {
          $makhoa=$_POST["makhoa"];
          $tenkhoa=$_POST["tenkhoa"];
			$str = "insert into khoa values ('$makhoa', '$tenkhoa')";
			mysql_query($str, $conn);
        }
    ?>
<form method=post>
<table border="1">
  <tbody>
    <tr>
      <td>Mã khoa:
        <input type="text" name="makhoa"></td>
      </tr>
    <tr>
      <td>Tên khoa:
        <input type="text" name="tenkhoa"></td>
      </tr>
      <tr>
        <td align="center"><input type="submit" name="them" id="them" value="Thêm">
        <input type="reset" name="reset" id="reset" value="Reset"></td>
      </tr>
  </tbody>
</table>
</form>
<div><a href="admin.php">Quay về trang admin</a></div>
</body>
</html>
