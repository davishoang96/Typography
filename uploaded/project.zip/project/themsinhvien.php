<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
 <script src="jquery.js"></script>
<?php
include "connect.php";
$str0="select * from khoa";
   $rs=mysql_query($str0,$conn);

        if(isset($_POST['them'])) {
          $gt = $_POST["gioitinh"];
          $mssv=$_POST["mssv"];
          $ten=$_POST["ten"];
            $ngaysinh = $_POST["ngaysinh"];
            $lop = $_POST["lop"];
			$cmnd=$_POST["cmnd"];
			$manganh=$_POST["manganh"];
			$str = "insert into sinhvien values ('$mssv', '$ten','$manganh','$lop','$cmnd','$ngaysinh','$gt')";
            $str1="insert into login values ('$mssv','$cmnd','3')";
			mysql_query($str, $conn);
			mysql_query($str1,$conn);
        }
    ?>
<form method=post>
<table border="1">
  <tbody>
    <tr>
      <td>Mã số sinh viên:
        <input type="text" name="mssv"></td>
      </tr>
    <tr>
      <td align="center">Họ và Tên:
        <input type="text" name="ten"></td>
      </tr>
      <tr>
      <td align="center">Ngành:  <select name="manganh" id="manganh">
            <?php while($row=mysql_fetch_row($rs)):;?>
             <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
             <?php endwhile;?>
        </select></td>
      </tr>
    <tr>
      <td align="center">Lớp:
        <input type="text" name="lop"></td>
      </tr>
      <tr>
      <td align="center">Số CMND:
        <input type="text" name="cmnd"></td>
      </tr>
    <tr>
      <td align="center">Ngày Sinh:
        <input type="date" name="ngaysinh"></td>
      </tr>
    <tr>
      <td align="center">Giới Tính:
        <input type="radio" name="gioitinh" value="1">
        Nam <input type="radio" name="gioitinh" value="0"> Nữ </td>
      </tr>
      <tr>
        <td align="center"><input type="submit" name="them" id="them" value="Thêm">
        <input type="reset" name="reset" id="reset" value="Reset"></td>
      </tr>
  </tbody>
</table>
</form>
<a href="admin.php">Quay về trang admin</a>
</body>
</html>
