<?php
	include "connect.php";
	$magv=$_POST['magv'];
	$str="delete from giaovien where magv='$magv'";
	$str1="delete from login where id='$magv'";
	if(mysql_query($str,$conn) && mysql_query($str1,$conn))
		echo "Xóa thành công";
	else
		echo "Xóa không được";
?>