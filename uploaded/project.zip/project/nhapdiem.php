<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script src="jquery.js"></script>
<script>
$(document).ready(function(){
  $("#malop").click(function(){
    var malop=$("#malop").val();
    $.get("nhapdiem_ajax.php?malop="+malop,function(data,status){
      $("#iddiv").html(data);
    });//end get
  });//end key up
});
</script>
</head>

<body>
<?php
	include "connect.php";
	$str="select * from lop";
	$rs=mysql_query($str,$conn);
	echo "<form>";
		echo "Tên lớp:";
		echo "<select id='malop'>";
		while($row=mysql_fetch_row($rs))
		{
			echo "<option value=$row[0]>$row[0]</option>";
		}
		echo "</select>";
	echo "</form>";
?>
<div id="iddiv"></div>
</body>
</html>
</body>
</html>
