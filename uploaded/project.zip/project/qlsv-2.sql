-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2016 at 10:09 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlsv`
--

-- --------------------------------------------------------

--
-- Table structure for table `bomon`
--

CREATE TABLE `bomon` (
  `mabomon` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `tenbomon` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `makhoa` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tinchi` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bomon`
--

INSERT INTO `bomon` (`mabomon`, `tenbomon`, `makhoa`, `tinchi`) VALUES
('CN001', 'Nhập Môn Lập Trình', 'CNTT', 4),
('CN002', 'Lập Trình Hướng Đối Tượng', 'CNTT', 4),
('CN003', 'Lập Trình Hướng Đối Tượng Nâng Cao', 'CNTT', 4),
('HH001', 'Hóa Học Cơ Bản', 'HH', 3),
('HH002', 'Hóa Học Nâng Cao ', 'HH', 4),
('VL001', 'Vật Lý Cơ Bản', 'VL', 3),
('VL002', 'Vật Lý Nâng Cao', 'VL', 3);

-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `magv` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `tengiaovien` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CMND` int(12) DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `gioitinh` tinyint(1) DEFAULT NULL,
  `makhoa` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mabomon` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `giaovien`
--

INSERT INTO `giaovien` (`magv`, `tengiaovien`, `CMND`, `ngaysinh`, `gioitinh`, `makhoa`, `mabomon`) VALUES
('GV01', 'Hứa Chí Cường', 12345679, '1996-03-26', 1, 'CNTT', 'CN003'),
('GV02', 'Nguyễn Tô Quốc Toàn', 456123789, '1996-11-11', 1, 'HH', 'HH001');

-- --------------------------------------------------------

--
-- Table structure for table `khoa`
--

CREATE TABLE `khoa` (
  `makhoa` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `tenkhoa` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khoa`
--

INSERT INTO `khoa` (`makhoa`, `tenkhoa`) VALUES
('CNTT', 'Công Nghệ Thông Tin'),
('HH', 'Hóa Học'),
('VL', 'Vật Lý');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `pass`, `level`) VALUES
('1459027', '025341928', 3),
('1459034', '12345679', 3),
('1459050', '12345679', 3),
('1459057', '34779180', 2),
('adminlatao', 'taolaadmin', 1),
('GV01', '12345679', 2),
('GV02', '456123789', 2);

-- --------------------------------------------------------

--
-- Table structure for table `lop`
--

CREATE TABLE `lop` (
  `malop` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lop`
--

INSERT INTO `lop` (`malop`) VALUES
('14BIT1'),
('14BIT2'),
('14HH1'),
('14HH2'),
('14VL1');

-- --------------------------------------------------------

--
-- Table structure for table `sinhvien`
--

CREATE TABLE `sinhvien` (
  `mssv` int(11) NOT NULL,
  `ten` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `makhoa` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `malop` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cmnd` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL,
  `gioitinh` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sinhvien`
--

INSERT INTO `sinhvien` (`mssv`, `ten`, `makhoa`, `malop`, `cmnd`, `ngaysinh`, `gioitinh`) VALUES
(1459027, 'Trang Trí Kiệt', 'CNTT', '14BIT2', '025341928', '1996-03-26', 1),
(1459034, 'Nguyễn Bình Minh', 'HH', '14HH1', '12345679', '1996-11-11', 1),
(1459050, 'Nguyễn Quốc Toàn', 'VL', '14VL1', '12345679', '1996-11-11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sv_mh`
--

CREATE TABLE `sv_mh` (
  `mssv` int(11) NOT NULL,
  `malop` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mabomon` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sv_mh`
--

INSERT INTO `sv_mh` (`mssv`, `malop`, `mabomon`) VALUES
(1459027, '14BIT2', 'CN001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bomon`
--
ALTER TABLE `bomon`
  ADD PRIMARY KEY (`mabomon`);

--
-- Indexes for table `khoa`
--
ALTER TABLE `khoa`
  ADD PRIMARY KEY (`makhoa`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lop`
--
ALTER TABLE `lop`
  ADD PRIMARY KEY (`malop`);

--
-- Indexes for table `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`mssv`);

--
-- Indexes for table `sv_mh`
--
ALTER TABLE `sv_mh`
  ADD PRIMARY KEY (`mssv`,`mabomon`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
