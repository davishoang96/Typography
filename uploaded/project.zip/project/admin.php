<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<table width="32%" border="1">
  <tbody>
    <tr>
      <td>Sinh viên</td>
      <td>Giáo viên</td>
      <td>Khoa</td>
      <td>Môn</td>
    </tr>
    <tr>
      <td>
      <ul style="list-style-type:circle">
  <li><a href="themsinhvien.php">Thêm</li>
  <li><a href="xoasinhvien.php">Xóa</li>
</ul>
      </td>
      <td>  <ul style="list-style-type:circle">
    <li><a href="themgiaovien.php">Thêm</li>
    <li><a href="xoagiaovien.php">Xóa</li>
  </ul>
      </td>
      <td>  <ul style="list-style-type:circle">
    <li><a href="themkhoa.php">Thêm</li>
    <li><a href="xoakhoa.php">Xóa</li>
  </ul></td>
       <td>  <ul style="list-style-type:circle">
     <li><a href="themmon.php">Thêm</li>
     <li><a href="xoamon.php">Xóa</li>
   </ul></td>
   <td>  <ul style="list-style-type:circle">
 <li><a href="themlop.php">Thêm</li>
 <li><a href="xoalop.php">Xóa</li>
</ul></td>
    </tr>
  </tbody>
</table>
<a href="index.php">Quay về trang chủ</a>
  </body>
</html>
