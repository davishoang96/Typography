<?php
	include "connect.php";
	$makhoa=$_GET['makhoa'];

	$str="select * from bomon where makhoa='$makhoa'";
	$rs=mysql_query($str,$conn);
		echo "<select id='mabomon' name='mabomon'>";
		while($row=mysql_fetch_row($rs))
		{
			echo "<option value=$row[0]>$row[1]</option>";
		}
		echo "</select>";
?>
