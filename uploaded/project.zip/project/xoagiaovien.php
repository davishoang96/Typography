<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
<script src="jquery.js"></script>
<script>
$(document).ready(function(){
  	$(".xoa").click(function(){
    var magv=$(this).attr('name');
	$(this).parent().parent().remove();
    $.post("xoagiaovien_ajax.php",
    	{
      		magv:magv
    	},
    	function(data,status){
      		if(status=="success")
      		{

				alert(data);

			}
		});
	});
});
</script>


</head>

<body>
<?php
	include "connect.php";
	$str="select * from giaovien";
	$rs=mysql_query($str,$conn);
	echo "<table border='1' cellspacing='0'>";
	echo "<tr><th>STT</th><th>Mã giáo viên</th><th>Tên giáo viên</th><th>Xóa</th></tr>";
	$i=1;
	while($row=mysql_fetch_row($rs))
	{
		echo "<tr><td>$i</td><td>$row[0]</td><td>$row[1]</td>
			<td> <input type='button' name=$row[0] class='xoa' value='Xóa'></input>

			</td>
		<tr>";
		$i++;
	}
	echo "</table>";
?>
<a href="admin.php">Quay về trang admin</a>
</body>
</html>
