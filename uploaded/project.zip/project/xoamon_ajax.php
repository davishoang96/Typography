<?php
	include "connect.php";
	$mabomon=$_POST['mabomon'];
	$str="delete from khoa where mabomon='$mabomon'";
	if(mysql_query($str,$conn))
		echo "Xóa thành công";
	else
		echo "Xóa không được";
?>
