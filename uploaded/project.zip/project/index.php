
<script src="jquery.js"></script>
<!DOCTYPE html>
<html>
  <?php require 'main/head.php'; ?>
  <?php include 'main/navbar.php'; ?>

<body>
  <body>

  </body>
</html>
