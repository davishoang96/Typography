<?php session_start();
error_reporting(0);
?>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">TRANG CHỦ</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav" >
        <li><?php
        if(isset($_SESSION['id']))
        echo"<a href='check_diem.php'>XEM ĐIỂM<span class='sr-only'>(current)</span></a>";
        else {
        echo"<a href='login.php'>XEM ĐIỂM<span class='sr-only'>(current)</span></a>";
        }
        ?>
        </li>
        <li><?php
          if(isset($_SESSION['id']))
          echo"<a href='dangkimonhoc.php' class='dangkimonhoc'>ĐĂNG KÍ MÔN HỌC<span class='sr-only'>(current)</span></a>";
          else {
          echo"<a href='login.php'>ĐĂNG KÍ MÔN HỌC<span class='sr-only'>(current)</span></a>";
          }
          ?></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="thongtin.php">Thông Tin Tài Khoản</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php
          include"connect.php";
          if (isset($_SESSION['id'])) {
            $id=$_SESSION['id'];
            $str=("select * from sinhvien where mssv='$id'");
            $rs=mysql_query($str,$conn);
            $row=mysql_fetch_row($rs);
          echo"<label href='function/logout.php'>$row[1]</label>";
          //echo $row[1];
          } else {
            echo "Tài Khoản";
          }
          ?><span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><?php
              if(isset($_SESSION['id']))
              echo"<a href='logout.php'>Đăng xuất</a>";
              else {
                echo"<a href='login.php'>Đăng nhập</a>";
              }
              ?></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
