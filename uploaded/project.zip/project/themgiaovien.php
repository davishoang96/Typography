<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
 <script src="jquery.js"></script>
 <script>
 $(document).ready(function(){
   $("#makhoa").click(function(){
   var makhoa=$("#makhoa").val();
     $.get("themgiaovien_ajax.php?makhoa="+makhoa,function(data,status){
       $("#bomon").html(data);
     });//end get
   });//end key up
 });//end ready
 </script>
<?php
include "connect.php";
$str1="select * from khoa";
   $rs=mysql_query($str1,$conn);

        if(isset($_POST['them'])) {
          $gt = $_POST["gioitinh"];
          $msgv=$_POST["msgv"];
          $ten=$_POST["ten"];
            $ngaysinh = $_POST["ngaysinh"];
            $mabomon = $_POST["mabomon"];
			$cmnd=$_POST["cmnd"];
			$makhoa=$_POST["makhoa"];
			$str = "insert into giaovien values ('$msgv', '$ten' ,'$cmnd','$ngaysinh','$gt','$makhoa','$mabomon')";
      //chưa làm ajax
            $str1="insert into login values ('$msgv','$cmnd','2')";
			mysql_query($str, $conn);
			mysql_query($str1,$conn);
        }
    ?>
<form method=post>
<table border="1">
  <tbody>
    <tr>
      <td>Mã số giáo viên:
        <input type="text" name="msgv"></td>
      </tr>
    <tr>
      <td align="center">Họ và Tên:
        <input type="text" name="ten"></td>
      </tr>
      <tr>
      <td align="center">Khoa  <select name="makhoa" id="makhoa">
            <?php while($row=mysql_fetch_row($rs)):;?>
             <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
             <?php endwhile;?>
        </select></td>
      </tr>
    <tr>
      <td align="center">Bộ Môn:
        <div id="bomon"></div></td>
      </tr>
      <tr>
      <td align="center">Số CMND:
        <input type="text" name="cmnd"></td>
      </tr>
    <tr>
      <td align="center">Ngày Sinh:
        <input type="date" name="ngaysinh"></td>
      </tr>
    <tr>
      <td align="center">Giới Tính:
        <input type="radio" name="gioitinh" value="1">
        Nam <input type="radio" name="gioitinh" value="0"> Nữ </td>
      </tr>
      <tr>
        <td align="center"><input type="submit" name="them" id="them" value="Thêm">
        <input type="reset" name="reset" id="reset" value="Reset"></td>
      </tr>
  </tbody>
</table>
</form>
<div><a href="admin.php">Quay về trang admin</a></div>
</body>
</html>
