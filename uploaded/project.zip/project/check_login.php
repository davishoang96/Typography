<script src="jqery.js"></script>
<?php

error_reporting(0);
require 'main/head.php';
require 'connect.php';

if (isset($_POST['submit'])) {
    $ID = $_POST['id'];
    $PASS = $_POST['pass'];

    if ($ID == '' || $PASS == '') {
        echo "<script>alert('KHÔNG ĐƯỢC ĐỂ TRỐNG TÊN ĐĂNG NHẬP HOẶC MẬT KHẨU')</script>";
    } else {
        $result = mysql_query("SELECT * FROM login WHERE id ='$ID' AND pass = '$PASS' AND level ", $conn);
        if (mysql_num_rows($result) > 0) {
            while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
              //if level = 1 -> goto admin.php
                if ($row['id'] == $ID && $row['pass'] == $PASS && $row['level'] == '1') {
                    session_start();
                    $_SESSION['id'] = $ID;
                    header("location: admin.php");
                }
            }
        }$result = mysql_query("SELECT * FROM login WHERE id ='$ID' AND pass = '$PASS' ", $conn);
        if (mysql_num_rows($result) > 0) {
            while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
              //if level = 0 -> goto index.php
                if ($row['id'] == $ID && $row['pass'] == $PASS && $row['level'] == '2') {
                    $_SESSION['id'] = $ID;
                    header("location: giaovien.php");
                }
            }

        } $result = mysql_query("SELECT * FROM login WHERE id ='$ID' AND pass = '$PASS' ", $conn);
        if (mysql_num_rows($result) > 0) {
            while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
              //if level = 0 -> goto index.php
                if ($row['id'] == $ID && $row['pass'] == $PASS && $row['level'] == '3') {
                    $_SESSION['id'] = $ID;
                    header("location: index.php");
                }
            }
        } else {
          echo "<script>alert('sai tên đăng nhập hoặc sai mật khẩu')</script>";;
        }
    }
}

?>
