<?php
session_start();
error_reporting(0);
?>
<!doctype html>
<html>
<?php require 'main/head.php'; ?>
<?php include 'main/navbar.php'; ?>
<?php
	include "connect.php";
  $var=$_SESSION['id'];
  $str=("select * from sinhvien where mssv='$var'");
  $rs=mysql_query($str,$conn);
  $row=mysql_fetch_row($rs);
  $malop=$row[3];
  $makhoa=$row[2];

	  $mabomon=$_POST['mabomon'];
	  if(isset($_POST['dangki']))
  	{
	 foreach($mabomon as $mh)
	 {

		 $str2 = "insert into sv_mh values ('$var','$malop','$mh')";
		 mysql_query($str2,$conn);
	 }

  }

?>
<?php
	$str1="select * from bomon where makhoa='$makhoa'";
	$rs1=mysql_query($str1,$conn);
	echo"<form method='post'>";
	echo "<table border='1'>";
	echo "<tr><th>STT</th><th>Mã Bộ Môn</th><th>Tên Bộ Môn</th><th>Click vào ô để chọn</th></tr>";
	$i=1;
	while($row1=mysql_fetch_row($rs1))
	{
		echo "<tr><td>$i</td><td>$row1[0]</td><td>$row1[1]</td>";
	$str3="select * from sv_mh where mssv='$var' and mabomon='$row1[0]'";
	$rs3=mysql_query($str3,$conn);
	if(mysql_num_rows($rs3)>0)
	{
	echo"<td>Đã đăng kí</td>";
	}
	else
	{
	echo"<td><input type='checkbox' value='$row1[0]' name='mabomon[]'/></td></tr>";
	}
	$i++;
	}
	echo"<tr><td align='center'><input type='submit' name='dangki' id='dangki' value='Đăng Kí'></td></tr>";
	echo "</table>";
	echo"</form>";

?>
</body>
</html>
