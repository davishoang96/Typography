<!DOCTYPE html>
<html>
  <?php require 'main1/head.php'; ?>
  <?php include 'main1/navbar.php'; ?>
  <body>

  </body>
</html>
