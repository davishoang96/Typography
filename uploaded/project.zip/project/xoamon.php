<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
<script src="jquery.js"></script>
<script>
 $(document).ready(function(){
   $("#makhoa").click(function(){
   var makhoa=$("#makhoa").val();
     $.get("xoamon_ajax1.php?makhoa="+makhoa,function(data,status){
       $("#bomon").html(data);
     });
   });
 });
$(document).ready(function(){
  	$(".xoa").click(function(){
    var mabomon=$(this).attr('name');
	$(this).parent().parent().remove();
    $.post("xoamon_ajax.php",
    	{
      		mabomon:mabomon
    	},
    	function(data,status){
      		if(status=="success")
      		{

				alert(data);

			}
		});
	});
});
</script>


</head>

<body>
  <?php
  include "connect.php";
  $str1="select * from khoa";
    $rs1=mysql_query($str1,$conn);
     ?>
  Xóa môn theo khoa:<br>
  <select id="makhoa" name="makhoa">
  <?php while($row=mysql_fetch_row($rs1)):;?>
   <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
  <?php endwhile;?></select><br> 
<div id="bomon"></div>
<a href="admin.php">Quay về trang admin</a>
</body>
</html>
