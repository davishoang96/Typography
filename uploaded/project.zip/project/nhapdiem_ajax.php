<?php

	$malop=$_GET["malop"];

	include "connect.php";
	$str="select * from sv_mh where malop='$malop'";
	$rs=mysql_query($str,$conn);
	echo "<table border='1'>";
	echo "<tr><th>STT</th><th>MSSV</th><th>Tên Học Sinh</th><th>Điểm Số</th></tr>";
	$i=1;
	while($row=mysql_fetch_row($rs))
	{
		echo "<tr><td>$i</td><td>$row[0]</td><td>$row[1]</td><input type='text'>$row[]</input></tr>";
		$i++;
	}
	echo "</table>";
?>
