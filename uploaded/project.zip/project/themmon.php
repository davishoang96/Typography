<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
 <script src="jquery.js"></script>
<?php
include "connect.php";
$str1="select * from khoa";
$rs=mysql_query($str1,$conn);
        if(isset($_POST['them'])) {
          $mabomon=$_POST["mabomon"];
          $tenbomon=$_POST["tenbomon"];
          $makhoa=$_POST["makhoa"];
          $sotinchi=$_POST["sotinchi"];

			$str = "insert into bomon values ('$mabomon', '$tenbomon','$makhoa','$sotinchi')";
			mysql_query($str, $conn);
        }
    ?>
<form method=post>
<table border="1">
  <tbody>
    <tr>
      <td>Mã Bộ Môn:
        <input type="text" name="mabomon"></td>
      </tr>
    <tr>
      <td>Tên Bộ Môn:
        <input type="text" name="tenbomon"></td>
      </tr>
      <td>Thuộc Khoa:
        <select id="makhoa" name="makhoa">
        <?php while($row=mysql_fetch_row($rs)):;?>
         <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
       <?php endwhile;?></select> </td>
      </tr>
    <tr>
      <td>Số Tín Chỉ:
        <input type="text" name="sotinchi"></td>
      </tr>
      <tr>
        <td align="center"><input type="submit" name="them" id="them" value="Thêm">
        <input type="reset" name="reset" id="reset" value="Reset"></td>
      </tr>
  </tbody>
</table>
</form>
<div><a href="admin.php">Quay về trang admin</a></div>
</body>
</html>
