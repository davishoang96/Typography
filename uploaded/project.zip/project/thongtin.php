<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<?php
session_start();
?>
<?php
	include "connect.php";
  $var=$_SESSION['id'];
  $str=("select * from sinhvien where mssv='$var'");
  $rs=mysql_query($str,$conn);
  $row=mysql_fetch_row($rs);
  $makhoa=$row[2];
   $str1=("select * from khoa where makhoa='$makhoa'");
  $rs1=mysql_query($str1,$conn);
  $row1=mysql_fetch_row($rs);?>

</script>
<body>
<form>
Mã số sinh viên: <?php echo"$row[0]";?><br>
Họ và Tên:<?php echo"$row[1]"; ?><br>
Lớp:<?php echo"$row[3]"; ?><br>
Nghành:<?php echo"$row1[2]"; ?><br>
Ngày Sinh:<?php echo"$row[5]";?><br>
Giới Tính:<?php if($row[6]==1){echo"Nam";}else{echo"Nữ";}?>
</form>
</body>
</html>