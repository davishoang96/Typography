<?php
	$malop=$_GET['malop'];
	include "connect.php";
	echo"$malop";
	$str="select * from hocsinh where MALOP='$malop'";
	$rs=mysql_query($str,$conn);
	echo "<table border='1'>";
	echo "<tr><th>STT</th><th>Tên Học Sinh</th></tr>";
	$i=1;
	while($row=mysql_fetch_row($rs))
	{
		echo "<tr><td>$i</td><td>$row[2]</td></tr>";
		$i++;
	}
	echo "</table>";
?>
