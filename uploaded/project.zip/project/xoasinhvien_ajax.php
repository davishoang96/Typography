<?php
	include "connect.php";
	$masv=$_POST['masv'];
	$str="delete from sinhvien where mssv='$masv'";
	$str1="delete from login where id='$masv'";
	if(mysql_query($str,$conn) && mysql_query($str1,$conn))
		echo "Xóa thành công";
	else
		echo "Xóa không được";
?>