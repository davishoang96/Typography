<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
include "connect.php";
        if(isset($_POST['them']))
        {
          $malop=$_POST["malop"];
            $str = "insert into lop values ('$malop')";
            mysql_query($str, $conn);
          }
    ?>
<form method="post">
<table width="15%" border="1">
  <tbody>
    <tr>
      <td align="center">Mã lớp	<input type="text" name="malop"></td>
      </tr>
    <tr>
      <td align="left"><input type="submit" name="them" id="them" value="Thêm"></td>
      </tr>
  </tbody>
</table>

</form>
</body>
</html>
