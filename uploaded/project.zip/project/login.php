<?php session_start();
      error_reporting(0);
 ?>
<!DOCTYPE html>
<html>
  <?php require "main/head.php"; ?>
  <?php include "main/navbar.php"; ?>
  <?php include "check_login.php"; ?>
  <head>
    <style media="screen">
      table, th, tr, td {
        margin: auto;
        border: 2px solid black;
      }

    </style>
  </head>
  <body>
    <form method="post">
      <table>
        <th colspan="2">
          Đăng nhập
        </th>
        <tr>
          <td>
            Tên tài khoảng:
          </td>
          <td>
            <input type="text" name="id" placeholder="Nhập tên tài khoảng">
          </td>
        </tr>
        <tr>
          <td>
            Mật khẩu:
          </td>
          <td>
            <input type="password" name="pass" placeholder="Nhập mật khẩu">
          </td>
        </tr>
        <th colspan="2">
          <button type="submit" name="submit">Login</button>
        </th>
      </table>
    </form>
  </body>
</html>
