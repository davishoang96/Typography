<?php
include"connect.php";
  $makhoa=$_GET["makhoa"];
	$str="select * from bomon where makhoa='$makhoa'";
	$rs=mysql_query($str,$conn);
	echo "Danh sách các bộ môn theo khoa:";
	echo "<table border='1' cellspacing='0'>";
	echo "<tr><th>STT</th><th>Mã Bộ Môn</th><th>Tên Bộ Môn</th><th>Xóa</th></tr>";
	$i=1;
	while($row=mysql_fetch_row($rs))
	{
		echo "<tr><td>$i</td><td>$row[0]</td><td>$row[1]</td>
			<td> <input type='button' name=$row[0] class='xoa' value='Xóa'></input>

			</td>
		<tr>";
		$i++;
	}
	echo "</table>";
?>