<?php
ob_start();
?>

<div >
    <div class="">
        <?
        include_once('config/db.php');

        $sql = 'SELECT p.*, c.name as category_name FROM tt_post p
                        JOIN tt_category c WHERE c.id = p.category_id';

        $rows = $db->query($sql);
        while ($row = $rows->fetch_assoc()) { ?>
            <article style="padding: 15px 0; border-bottom: 1px solid #cccccc">
                <a href="/post?id=<?php echo $row['id'] ?>"><h2 style="margin-top: 0px"><?php echo $row['name'] ?></h2></a>
                <small>
                    <a href="/category/?id=<?php echo $row['id'] ?>"><?php echo $row['category_name'] ?></a>
                    /
                    <?php echo date('Y-m-d h:i:s', strtotime($row['inserted_at'])) ?>
                </small>
                <p style="margin: 10px 0 0; font-style: italic"><?php echo $row['short'] ?></p>
            </article>
        <?php } ?>
    </div>
<!--    <div class="col-md-4">-->
<!--        def-->
<!--    </div>-->
</div>

<!--<div class="">
    <nav >
        <ul class="pagination">
            <li>
                <a href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <li><a href="#">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li>
                <a href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
</div>-->

<?php
$page_content = ob_get_contents();
ob_end_clean();

$title = "MY BLOG";

include("layout.php");
?>