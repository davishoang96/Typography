/* admin - 123 */

DROP TABLE IF EXISTS `tt_user`;
CREATE TABLE `tt_user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) DEFAULT NULL,
  `password` VARCHAR(50) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `role` TINYINT DEFAULT 1 COMMENT '0: admin, 1: editor',
  `inserted_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

INSERT INTO `tt_user` (id, username, password, role) VALUES
  (1, 'admin', '202cb962ac59075b964b07152d234b70', 0);

DROP TABLE IF EXISTS `tt_category`;
CREATE TABLE `tt_category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(250),
  `inserted_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

DROP TABLE IF EXISTS `tt_post`;
CREATE TABLE `tt_post` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT DEFAULT NULL,
  `category_id` INT DEFAULT NULL,
  `name` VARCHAR(250),
  `short` TEXT,
  `full` TEXT,
  `status` TINYINT DEFAULT 0 COMMENT '0: draft, 1: published',
  `published_at` TIMESTAMP NULL DEFAULT NULL,
  `inserted_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_post__user` (`user_id`),
  KEY `FK_post__category` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

ALTER TABLE `tt_post`
  ADD CONSTRAINT `FK_post__user` FOREIGN KEY (`user_id`) REFERENCES `tt_user` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_post__category` FOREIGN KEY (`category_id`) REFERENCES `tt_category` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION;