<?php
ob_start();
?>

<?
include_once('../config/db.php');

if (isset($_GET['id']) && $_GET['id']) {
    $id = $_GET['id'];
    $sql = 'SELECT * FROM tt_post WHERE category_id = ' . $id;

    $rows = $db->query($sql);
    while ($row = $rows->fetch_assoc()) { ?>
        <div >
            <article style="padding: 20px 0; border-bottom: 1px solid #cccccc">
                <a href="/post?id=<?php echo $row['id'] ?>"><h2><?php echo $row['name'] ?></h2></a>
                <small><?php echo date('Y-m-d', strtotime($row['inserted_at'])) ?></small>
                <p><?php echo $row['short'] ?></p>
            </article>
        </div>
        <!--    <div class="col-md-4">-->
        <!--        def-->
        <!--    </div>-->
    <?php }
} else {
    header('HTTP/1.0 404 Not Found');
    echo "<h1>404 Not Found</h1>";
    echo "The page that you have requested could not be found.";
    exit();
}
?>

<!--<div class="">
    <nav >
        <ul class="pagination">
            <li>
                <a href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <li><a href="#">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">5</a></li>
            <li>
                <a href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
</div>-->

<?php
$page_content = ob_get_contents();
ob_end_clean();

$title = "MY BLOG";

include("../layout.php");
?>