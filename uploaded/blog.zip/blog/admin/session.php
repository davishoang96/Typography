<?php

session_start();
$logined = false;
if (isset($_SESSION['username'])) {
    $logined = true;
}