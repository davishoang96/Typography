<?php
include('../check_logined.php');

ob_start();
?>

<a id="js-add" href="" class="btn btn-primary">Thêm bài viết</a>
<div id="js-create-form-panel" class="panel panel-info" style="display: none; margin-top: 20px">
    <div class="panel-body">
        <form id="js-create-form" >
            <div class="form-group">
                <label>Danh mục</label>
                <select class="form-control" name="category_id">
                <?php
                    include('../../config/db.php');

                    $sql = 'SELECT * FROM tt_category';

                    $rows = $db->query($sql);
                    $categories = array();
                    while ($row = $rows->fetch_assoc()) {
                        $categories[] = $row; ?>
                    <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Tên bài viết</label>
                <input type="text" class="form-control" name="name">
            </div>
            <div class="form-group">
                <label>Tóm tắt</label>
                <textarea rows="3" class="form-control" name="short"></textarea>
            </div>
            <div class="form-group">
                <label>Nội dung</label>
                <textarea class="form-control editor" name="full"></textarea>
            </div>
            <button id="js-create" class="btn btn-success">Thêm</button>
        </form>
    </div>
</div>

<div class="panel panel-info" style="margin-top: 20px">
    <div class="panel-body">
        <table class="table table-hover">
            <thead>
            <tr>
                <th>ID</th>
                <th>Danh mục</th>
                <th>Tên bài viết</th>
                <th>Tóm tắt</th>
                <th></th>
            </tr>
            </thead>
            <tbody id="js-list">
            <?php
                include('../../config/db.php');

                $sql = 'SELECT p.*, c.name as category_name FROM tt_post p
                        JOIN tt_category c WHERE c.id = p.category_id';

                $rows = $db->query($sql);
                if ($rows !== false) {
                    while ($row = $rows->fetch_assoc()) { ?>
                        <tr id="js-data<?php echo $row['id'] ?>">
                            <td><?php echo $row['id'] ?></td>
                            <td><?php echo $row['category_name'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['short'] ?></td>
                            <td style="width: 130px">
                                <a href="#" class="js-edit btn btn-info" data-id="<?php echo $row['id'] ?>">Sửa</a>
                                <a href="#" class="js-delete btn btn-danger" data-id="<?php echo $row['id'] ?>">Xóa</a>
                            </td>
                        </tr>
                        <tr id="js-update-form-panel<?php echo $row['id'] ?>" style="display: none">
                            <td colspan="5">
                                <div class="panel panel-info" style="margin-top: 20px">
                                    <div class="panel-body">
                                        <form id="js-update-form<?php echo $row['id'] ?>">
                                            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">

                                            <div class="form-group">
                                                <label>Danh mục</label>
                                                <select class="form-control" name="category_id">
                                                    <?php
                                                    foreach ($categories as $category) { ?>
                                                        <option value="<?php echo $category['id'] ?>" <?php echo $row['category_id'] == $category['id'] ? 'selected' : '' ?>><?php echo $category['name'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Tên bài viết</label>
                                                <input type="text" class="form-control" name="name" value="<?php echo $row['name'] ?>">
                                            </div>
                                            <div class="form-group">
                                                <label>Tóm tắt</label>
                                                <textarea rows="3" class="form-control" name="short"><?php echo $row['short'] ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label>Nội dung</label>
                                                <textarea class="form-control editor" name="full"><?php echo $row['full'] ?></textarea>
                                            </div>
                                            <button data-id="<?php echo $row['id'] ?>" class="js-update btn btn-success">Cập
                                                nhật
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php }
                } ?>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
    function init() {

        $('.editor').summernote({
            height: 250,                 // set editor height

            minHeight: null,             // set minimum height of editor
            maxHeight: null,             // set maximum height of editor

            toolbar: [
                ['style', ['style']],
                ['fontname', ['fontname']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['format', ['bold', 'italic', 'underline', 'clear']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']],
                ['table', ['table', 'hr']],
                ['insert', ['link', 'picture', 'video']],
                ['mix', ['codeview']]
            ]
        });
    }

    $(document).ready(function(){
       init();
    });

    $(document).on('click', '#js-add', function(e) {
        e.preventDefault();
        $('#js-create-form-panel').toggle();
    });

    $(document).on('click', '#js-create', function(e){
        e.preventDefault();

        var formData = $('#js-create-form').serialize();
        $.ajax({
            type: 'POST',
            url: "/admin/post/create.php",
            data: formData,
            success: function(data) {
                if(data.success) {
                    toastr.success('Thêm bài viết thành công!');
                    $('#js-create-form-panel').toggle();
                    $('#js-list').append(data.html);

                    $('.editor').each(function() {
                        $(this).summernote('destroy');
                    });
                    init();
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });

    $(document).on('click', '.js-edit', function(e) {
        e.preventDefault();

        var id = $(this).attr('data-id');
        $('#js-update-form-panel' + id).toggle();
    });

    $(document).on('click', '.js-update', function(e){
        e.preventDefault();

        var id = $(this).attr('data-id');

        var formData = $('#js-update-form' + id).serialize();
        $.ajax({
            type: 'POST',
            url: "/admin/post/update.php",
            data: formData,
            success: function(data) {
                if(data.success) {
                    toastr.success('Cập nhật bài viết thành công!');
                    $('#js-data' + id).replaceWith(data.html);
                    $('#js-update-form-panel' + id).replaceWith(data.detail);

                    $('.editor').each(function() {
                        $(this).summernote('destroy');
                    });
                    init();
                    //$('#js-update-form-panel' + id).toggle();
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });

    $(document).on('click', '.js-delete', function(e){
        e.preventDefault();

        var id = $(this).attr('data-id');
        var row = $('#js-data' + id);
        var detail = $('#js-update-form-panel' + id);

        $.ajax({
            type: 'POST',
            url: "/admin/post/delete.php",
            data: {
                id: id
            },
            success: function(data) {
                if(data.success) {
                    toastr.success('Xóa bài viết thành công!');
                    row.remove();
                    detail.remove();
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });
</script>

<?php
$page_content = ob_get_contents();
ob_end_clean();

$title = "Quản lý bài viết";

include("../layout.php");
?>

