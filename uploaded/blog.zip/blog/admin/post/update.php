<?php

header('Content-type: application/json');

if (isset($_POST['id']) && isset($_POST['category_id']) && isset($_POST['name']) && isset($_POST['short']) && isset($_POST['full'])) {
    include('../../config/db.php');

    $id = $_POST["id"];
    $category_id = $_POST["category_id"];
    $name = $_POST["name"];
    $short = $_POST["short"];
    $full = $_POST["full"];

    if (!$id || !$category_id || !$name || !$short || !$full) {
        $result = array(
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        );

        echo json_encode($result);
        die();
    }

    $name_value = "'" . $db->real_escape_string($name) . "'";
    $short_value = "'" . $db->real_escape_string($short) . "'";
    $full_value = "'" . $db->real_escape_string($full) . "'";
    $sql = "UPDATE tt_post SET
          category_id = $category_id,
          name = $name_value,
          short = $short_value,
          full = $full_value
          WHERE id = $id";

    if ($db->query($sql) === false) {
        //trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
        $result = array(
            'success' => false,
            'message' => $sql
        );

        echo json_encode($result);
    } else {
        $sql = "SELECT name FROM tt_category WHERE id = " . $category_id;
        $rows = $db->query($sql);
        $category_name = '';
        if ($rows !== false) {
            $row = $rows->fetch_assoc();
            $category_name = $row['name'];
        }

        $sql = 'SELECT * FROM tt_category';
        $rows = $db->query($sql);
        $select = "<select class='form-control' name='category_id'>";
        while ($row = $rows->fetch_assoc()) {
            $c_id = $row['id'];
            $c_name = $row['name'];
            $select .= "<option value='$c_id'" . ($c_id == $category_id ? "selected" : "") . ">$c_name</option>";
        }
        $select .= "</select>";

        $result = array(
            'success' => true,
            'html' =>   "<tr id='js-data$id'>
                            <td>$id</td>
                            <td>$category_name</td>
                            <td>$name</td>
                            <td>$short</td>
                            <td style='width: 130px'>
                                <a href='#' class='js-edit btn btn-info' data-id='$id'>Sửa</a>
                                <a href='#' class='js-delete btn btn-danger' data-id='$id'>Xóa</a>
                            </td>
                        </tr>",
            'detail' => "<tr id='js-update-form-panel$id' style='display: none'>
                            <td colspan='5'>
                                <div class='panel panel-info' style='margin-top: 20px'>
                                    <div class='panel-body'>
                                        <form id='js-update-form$id'>
                                            <input type='hidden' name='id' value='$id'>
                                            <div class='form-group'>
                                                <label>Danh mục</label>
                                                $select
                                            </div>
                                            <div class='form-group'>
                                                <label>Tên bài viết</label>
                                                <input type='text' class='form-control' name='name' value='$name'>
                                            </div>
                                            <div class='form-group'>
                                                <label>Tóm tắt</label>
                                                <textarea rows='3' class='form-control' name='short'>$short</textarea>
                                            </div>
                                            <div class='form-group'>
                                                <label>Nội dung</label>
                                                <textarea class='form-control editor' name='full'>$full</textarea>
                                            </div>
                                            <button data-id='$id' class='js-update btn btn-success'>Cập nhật</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>"
        );

        echo json_encode($result);
    }
} else {
    $result = array(
        'success' => false,
        'message' => 'Dữ liệu không hợp lệ'
    );

    echo json_encode($result);
}