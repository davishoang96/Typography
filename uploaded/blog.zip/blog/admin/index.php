<?php
ob_start();
?>

<?php
    include_once('session.php');
    if ($logined) {
        header("Location:/admin/post");
    }
?>

<div class="col-md-offset-3 col-md-4">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title">Đăng nhập</h3>
        </div>
        <div class="panel-body">
            <form id="js-login-form">
                <div class='form-group'>
                    <label>Username</label>
                    <input type='text' class='form-control' name='username'>
                </div>
                <div class='form-group'>
                    <label>Mật khẩu</label>
                    <input type='password' class='form-control' name='password'>
                </div>
                <button id="js-login" class='btn btn-success'>Đăng nhập</button>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '#js-login', function(e) {
        e.preventDefault();

        var formData = $('#js-login-form').serialize();
        $.ajax({
            type: 'POST',
            url: "/admin/login.php",
            data: formData,
            success: function(data) {
                if (data.success) {
                    window.location = '/admin/post';
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });
</script>

<?php
$page_content = ob_get_contents();
ob_end_clean();

$title = "ADMIN";

include("layout.php");
?>