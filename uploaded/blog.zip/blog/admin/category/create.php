<?php

header('Content-type: application/json');

if (isset($_POST['name'])) {
    include('../../config/db.php');

    $name = $_POST["name"];
    if (!$name) {
        $result = array(
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        );

        echo json_encode($result);
        die();
    }

    $name_value = "'" . $db->real_escape_string($name) . "'";
    $sql = "INSERT INTO tt_category (name) VALUES ($name_value)";

    if ($db->query($sql) === false) {
        //trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
        $result = array(
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        );

        echo json_encode($result);
    } else {
        $id = $db->insert_id;
//        $affected_rows = $conn->affected_rows;
        $result = array(
            'success' => true,
            'html' =>   "<tr id='js-data$id'>
                            <td>$id</td>
                            <td>$name</td>
                            <td>
                                <a href='#' class='js-edit btn btn-info' data-id='$id'>Sửa</a>
                                <a href='#' class='js-delete btn btn-danger' data-id='$id'>Xóa</a>
                            </td>
                        </tr>
                        <tr id='js-update-form-panel$id' style='display: none'>
                            <td colspan='3'>
                                <div class='panel panel-info' style='margin-top: 20px'>
                                    <div class='panel-body'>
                                        <form id='js-update-form'>
                                            <input type='hidden' name='id' value='$id'>
                                            <div class='form-group'>
                                                <label>Tên danh mục</label>
                                                <input type='text' class='form-control' name='name' value='$name'>
                                            </div>
                                            <button data-id='$id' class='js-update btn btn-success'>Cập nhật</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>"
        );

        echo json_encode($result);
    }
} else {
    $result = array(
        'success' => false,
        'message' => 'Dữ liệu không hợp lệ'
    );

    echo json_encode($result);
}