<?php
include('../check_logined.php');

ob_start();
?>

<a id="js-add" href="" class="btn btn-primary">Thêm danh mục</a>
<div id="js-create-form-panel" class="panel panel-info" style="display: none; margin-top: 20px">
    <div class="panel-body">
        <form id="js-create-form" >
            <div class="form-group">
                <label>Tên danh mục</label>
                <input type="text" class="form-control" name="name">
            </div>
            <button id="js-create" class="btn btn-success">Thêm</button>
        </form>
    </div>
</div>

<div class="panel panel-info" style="margin-top: 20px">
    <div class="panel-body">
        <table class="table table-hover">
            <thead>
            <tr>
                <th>ID</th>
                <th>Tên danh mục</th>
                <th></th>
            </tr>
            </thead>
            <tbody id="js-list">
            <?php
                include('../../config/db.php');

                $sql = 'SELECT * FROM tt_category';

                $rows = $db->query($sql);
                //$rows->data_seek(0);
                while ($row = $rows->fetch_assoc()) { ?>
                <tr id="js-data<?php echo $row['id'] ?>">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td>
                        <a href="#" class="js-edit btn btn-info" data-id="<?php echo $row['id'] ?>">Sửa</a>
                        <a href="#" class="js-delete btn btn-danger" data-id="<?php echo $row['id'] ?>">Xóa</a>
                    </td>
                </tr>
                <tr id="js-update-form-panel<?php echo $row['id'] ?>" style="display: none">
                    <td colspan="3">
                        <div class='panel panel-info' style='margin-top: 20px'>
                            <div class='panel-body'>
                                <form id="js-update-form<?php echo $row['id'] ?>">
                                    <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                    <div class="form-group">
                                        <label>Tên danh mục</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo $row['name'] ?>">
                                    </div>
                                    <button data-id="<?php echo $row['id'] ?>" class="js-update btn btn-success">Cập nhật</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>

            <?php } ?>

            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
    $(document).on('click', '#js-add', function(e) {
        e.preventDefault();
        $('#js-create-form-panel').toggle();
    });

    $(document).on('click', '#js-create', function(e){
        e.preventDefault();

        var formData = $('#js-create-form').serialize();
        $.ajax({
            type: 'POST',
            url: "/admin/category/create.php",
            data: formData,
            success: function(data) {
                if(data.success) {
                    toastr.success('Thêm danh mục thành công!');
                    //$('#js-form-panel').toggle();
                    $('#js-list').append(data.html);
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });

    $(document).on('click', '.js-edit', function(e) {
        e.preventDefault();

        var id = $(this).attr('data-id');
        $('#js-update-form-panel' + id).toggle();
    });

    $(document).on('click', '.js-update', function(e){
        e.preventDefault();

        var id = $(this).attr('data-id');

        var formData = $('#js-update-form' + id).serialize();
        $.ajax({
            type: 'POST',
            url: "/admin/category/update.php",
            data: formData,
            success: function(data) {
                if(data.success) {
                    toastr.success('Cập nhật danh mục thành công!');
                    $('#js-data' + id).replaceWith(data.html);
                    $('#js-update-form-panel' + id).replaceWith(data.detail);
                    //$('#js-update-form-panel' + id).toggle();
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });

    $(document).on('click', '.js-delete', function(e){
        e.preventDefault();

        var id = $(this).attr('data-id');
        var row = $('#js-data' + id);
        var detail = $('#js-update-form-panel' + id);

        $.ajax({
            type: 'POST',
            url: "/admin/category/delete.php",
            data: {
                id: id
            },
            success: function(data) {
                if(data.success) {
                    toastr.success('Xóa danh mục thành công!');
                    row.remove();
                    detail.remove();
                } else {
                    toastr.error(data.message);
                }
            },
        }).done(function() {
            //window.location.href = 'index.php';
        });
    });
</script>

<?php
$page_content = ob_get_contents();
ob_end_clean();

$title = "Quản lý danh mục";

include("../layout.php");
?>

