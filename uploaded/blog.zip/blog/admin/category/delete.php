<?php

header('Content-type: application/json');

if (isset($_POST['id'])) {
    include('../../config/db.php');

    $id = $_POST['id'];
    if (!$id) {
        $result = array(
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        );

        echo json_encode($result);
        die();
    }

    $sql = "DELETE FROM tt_category WHERE id = " . $id;

    if ($db->query($sql) === false) {
        //trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
        $result = array(
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        );

        echo json_encode($result);
    } else {
        $result = array(
            'success' => true
        );

        echo json_encode($result);
    }
} else {
    $result = array(
        'success' => false,
        'message' => 'Dữ liệu không hợp lệ'
    );

    echo json_encode($result);
}