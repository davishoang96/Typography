<!DOCTYPE html>
<html lang="vi">
<head>
    <title><?php echo $title ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <script src="/lib/jquery/jquery.min.js"></script>

    <link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css"/>
    <script src="/lib/bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="/lib/toastr/toastr.min.css"/>
    <script src="/lib/toastr/toastr.min.js"></script>
    <script>
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "progressBar": false,
            "positionClass": "toast-bottom-right",
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "3000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    </script>

    <link rel="stylesheet" href="/lib/summernote/summernote.css"/>
    <script src="/lib/summernote/summernote.min.js"></script>
</head>
<body>
<header class="navbar navbar-inverse navbar-static-top bs-docs-nav">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#bs-navbar" aria-controls="bs-navbar" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/admin" class="navbar-brand">ADMIN</a>
        </div>
        <nav id="bs-navbar" class="collapse navbar-collapse">
            <?php
            include_once('session.php');
            if ($logined) { ?>
                <ul class="nav navbar-nav">
                    <li><a href="/">Trang chủ</a></li>
                    <li><a href="/admin/category">Quản lý danh mục</a></li>
                    <li><a href="/admin/post">Quản lý bài viết</a></li>
<!--                    <li><a href="/admin/user">Quản lý tài khoản</a></li>-->
                </ul>

                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><?= $_SESSION['username'] ?></a></li>
                    <li><a href="/admin/logout.php">Đăng xuất</a></li>
                </ul>
            <?php } else { ?>
                <ul class="nav navbar-nav">
                    <li><a href="/">Trang chủ</a></li>
                </ul>
            <?php } ?>
        </nav>
    </div>
</header>

<div class="container">
    <?php echo $page_content ?>
</div>

<footer>
</footer>
</body>
</html>
