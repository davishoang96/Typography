<?php

include_once('session.php');
if (!$logined)
    header("Location:/admin/");