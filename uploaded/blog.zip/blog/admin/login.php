<?php

header('Content-type: application/json');

if (isset($_POST['username']) && $_POST['password'] && isset($_POST['password']) && $_POST['password']) {
    include('../config/db.php');

    $username = $_POST['username'];
    $password = $_POST['password'];

    $username_value = "'" . $db->real_escape_string($username) . "'";
    $sql = "SELECT * FROM tt_user WHERE username = $username_value";
    $rows = $db->query($sql);

    if ($rows !== false) {
        $row = $rows->fetch_assoc();
        if (md5($password) == $row['password']) {   //Correct password => Logined
            session_start();

            $_SESSION['username'] = $username;

            $result = array(
                'success' => true
            );
        } else
            $result = array(
                'success' => false,
                'message' => 'Username hoặc Mật khẩu không chính xác!'
            );
    } else
        $result = array(
            'success' => false,
            'message' => 'Username hoặc Mật khẩu không chính xác!'
        );

    echo json_encode($result);
} else {
    $result = array(
        'success' => false,
        'message' => 'Nhập Username và Mật khẩu!'
    );

    echo json_encode($result);
}