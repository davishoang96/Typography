<?php

$db_config = json_decode(file_get_contents(dirname(__FILE__) . '/db.json'), true);

$db = new mysqli($db_config['host'], $db_config['user'], $db_config['password'], $db_config['database']);
$db->set_charset("utf8");
if ($db->connect_errno) {
    die("Không kết nối được vào cơ sở dữ liệu MySQL");
}