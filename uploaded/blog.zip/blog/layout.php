<!DOCTYPE html>
<html lang="vi">
<head>
    <title><?php echo $title ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <link rel="stylesheet" href="/lib/bootstrap/css/bootstrap.min.css"/>
    <script src="/lib/jquery/jquery.min.js"></script>
</head>
<body>
<header class="navbar navbar-inverse navbar-static-top bs-docs-nav">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#bs-navbar" aria-controls="bs-navbar" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/" class="navbar-brand">MY BLOG</a>
        </div>
        <nav id="bs-navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <?php
                include_once('config/db.php');

                $sql = 'SELECT * FROM tt_category';

                $rows = $db->query($sql);
                while ($row = $rows->fetch_assoc()) { ?>
                    <li><a href="/category/?id=<?php echo $row['id'] ?>"><?php echo $row['name'] ?></a></li>
                <?php } ?>
            </ul>
            <?php
            include_once('admin/session.php');
            if ($logined) { ?>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/admin">ADMIN</a></li>
            </ul>
            <?php } ?>
        </nav>
    </div>
</header>

<div class="container">
    <?php echo $page_content ?>
</div>

<footer>
</footer>
</body>
</html>
